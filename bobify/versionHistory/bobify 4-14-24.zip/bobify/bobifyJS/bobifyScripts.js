//SORRY FOR THE CLUTTER ITS BECOME VERY HECTIC SO I SET EVERYTHING AS A COMMENT. CLOSE EVERYTHING ABOVE LINE 69.


/*
/*Data Type: Number - Stores the value 4 under "number_of_song_titles_listed"
var number_of_song_titles_listed = 4;

/*Data Type: String - Stores the words "bobify classics" under "collection_title"
var collection_title = "bobify classics";

/*Data Type: Array - Stores a list of strings (song titles in this case) under the variable "listed_titles"
var listed_titles = ["Dancing in the Moonlight", "Space Oddity", "House of the Rising Sun", "Sittin on the Dock of the Bay"]

/*Data Type: Object - Creates a dictionary like list that stores keys in correlation to song names, number arrays, and boolean values (in this case)
/*I addressed the the key issue. I wanted to id them by the order they would play if you started the playlist without shuffling it.
var bobify_titles_dictionary = {
    "Q1": "Dancing in the Moonlight",
    "Q2": "Space Oddity",
    "Q3": "House of the Rising Sun",
    "Q4": "(Sittin' On) the Dock of the Bay",
    "queue": ["Dancing in the Moonlight", "Space Oddity", "House of the Rising Sun", "Sittin on the Dock of the Bay"],
    "favorite-order": [2, 1, 3, 4],
    "shuffled": false
}
*/
/*
Tells HTML to do "alert(Congratulations....." When youpressedtheuglybutton function is called *WITH AN ARGUMENT*
So if you do <button onclick="youpressedtheuglybutton(bobifyuser)"></button> it will automatically write the alert prompt.

The ingredient/argument in this function is the user of the website. The function knows someone pressed the button but we have
to tell it WHO pressed the button. Then the alert will use the preset below to address the person we said pressed it.

In this case the data type of the argument can be a string because we only need a word name.
*/
function youpressedtheuglybutton(bobifyuser) {

    alert("Congratulations " + bobifyuser + " you pressed the ugly button.");

};
/*
For loops will work under 3 set parameters: 
you define a constant, then you define what the loop is checking for based on that constant. Then you define an interval inbetween checks.
while true, the loop will execute whats in the curly brackets. then it goes back and does the process again.

EXAMPLE: 
These lines 62-65 will help explain the loop in context.
var appleBasket2 = 9;
var takeSip = "You had something to drink"
applebasket++ essentially means to add 1 to our defined value, we will define our value to be 1.

So this is what our for loop is saying.

If our apple basket with only one apple, has less apples than a basket with 9, add one apple to the basket.
for (appleBasket = 1, appleBasket < appleBasket2; appleBasket++;)

But say its really hot out and we dont have the energy to do it all in one go, we can add actions to our loop.
In this context we want to take a sip of water for every apple we put into our basket. Here's how its done.

for (appleBasket = 1, appleBasket < appleBasket2; appleBasket++;) {
    console.log(takeSip)
}

Everytime our loop repeats based on what our loop is checking for (if appleBasket has less than appleBasket2)
It will complete the action we give it inside the curly braces. This loop prints in the console "You had something to drink"
each time we take another take another apple.
*/

/*
With our newfound explanation we can now read the for loop below as this:

  If the we're counting songs starting from zero, and the length of the playlist is greater than what we counted, add one to our count.
  Each time we add one to our count, print out the playlist entry correlating to what number we're on, Then repeat.
*/

//-----------------------------------------------------------------------------------------------------------------------------

//<div class="individual-song-container-styling">
//    <div class="individual-title-attributes">Dancing in the Moonlight</div>
//    <div><a class="artist-hyperlinks" href="https://open.spotify.com/artist/5FHwr1FymaS5kutIEK6e2y?go=1&sp_cid=7f61a2ef8dea5d657a80a610a877fe1a&utm_source=embed_player_p&utm_medium=desktop&nd=1&dlsi=33edfca4e53c44a9">King Harvest</a></div>
//    <div><img class="song-image-attributes" src="https://upload.wikimedia.org/wikipedia/en/7/78/Dancinginthemoonlightboffalongo.jpg" /></div>
//    <div>Duration: 2:52 - 172s</div>
//</div>

// NOTE: Variables marked HTML refer to content shown to the user. Variables Marked DATA are calling information from objects

// This variable contains the entire body
var HTMLBobifySongListing = document.getElementById("promoted-songs-list")

// Grabs the search button labeled confirm search in our HTML and stores it inside of this variable
// Storing it inside this variable allows us to manipulate the button using javaScript functions.
var HTMLConfirmSearchButton = document.getElementById("ConfirmSearch")

// This code tells the button to run the PullSearch Query function defined below on-click.
HTMLConfirmSearchButton.addEventListener("click", PullSearchQuery)


//This function starts by creating a variable and sets it equal the search box "QueryContainer" on the page
//After that it creates another variable to grab the search term within the search box. It then prints the content.
function PullSearchQuery() {
    var QueryContainer = document.getElementById("SearchQueryContainer")
    var TotallyUniqueSearchTerm = QueryContainer.innerHTML

    //Gets the list of all elements within ALL divs.
    var DATASongInformationByClassName = document.getElementsByClassName("individual-song-container-styling")
    //This for loop runs through each of the divs on the page, if the search term matches a title it will be shown.
    //Otherwise if the title does not match the searchterm it will not be shown.
    for (CheckedDivs = 0; CheckedDivs <= DATABobifySongListing.length; CheckedDivs++) {
        //Gets the song div for this iteration of the loop.
        var HTMLDivPositionCurrentlyBeingChecked = DATASongInformationByClassName[CheckedDivs];
        //Gets the elements array for the title div.
        var DATAElementsCurrentlyBeingChecked = HTMLDivPositionCurrentlyBeingChecked.getElementsByClassName("individual-title-attributes");
        //Saves the title information embedded in the html for this iteration for comparison.
        var HTMLDivTitle = DATAElementsCurrentlyBeingChecked[0].innerHTML;
        
        //Compares this iterations title div content to the search term, and filters it based of it is equal or not.
        //To make the search a little more lenient all search results and titles are formated back to lowercase to account for capitalization.
        //If they match, the div is shown as is, otherwise the div is hidden.
        if (HTMLDivTitle.toLowerCase() === TotallyUniqueSearchTerm.toLowerCase()) {
            HTMLDivPositionCurrentlyBeingChecked.style.display = "block"
        }else{
            HTMLDivPositionCurrentlyBeingChecked.style.display = "none"
        }

        if (TotallyUniqueSearchTerm.length <= 1){
            HTMLDivPositionCurrentlyBeingChecked.style.display = "block"
        }
    }
}

for (bobifySongsCounted = 0; bobifySongsCounted <= DATABobifySongListing.length; bobifySongsCounted++) {
    
    //This variable will act as our database, pulling information from our source object.
    var DATASongInformation = DATABobifySongListing[bobifySongsCounted]

    //Variable that creates the div which contains song information
    var HTMLlistedSongContainer = document.createElement('div');
    HTMLlistedSongContainer.classList.add("individual-song-container-styling")

    //Creates variable to hold title div.
    //Then sets the inner content of the div to be equal be the information linked to key A.
    //After the div is filled with content it is added to the encompassing div containing the entire body.
    //Further Information about keys located in "bobifySongArray.js"
    var HTMLSongTitleDiv = document.createElement('div');
    HTMLSongTitleDiv.classList.add("individual-title-attributes") 
    HTMLSongTitleDiv.innerHTML = DATASongInformation["CollectionKeyA"]
    HTMLlistedSongContainer.appendChild(HTMLSongTitleDiv)

    //Creates a div to hold the artists' name. Then creates a clickable attribute <a></a>.
    //Using the href property we set the address of the <a> tag to be the same as the information linked to key B.
    //After the address is set we fill the contents of the tag to be the same as the information linked to key E.
    //So "keyE" ---> keyB when clicked.
    //Once this is complete the <a> tag is added to the div meant to hold the artist name.
    //Then the artist name div is added to the encompassing div containing the entire body.
    var HTMLArtistHyperLinkDiv = document.createElement('div');
    var HTMLArtistClickable = document.createElement("a"); HTMLArtistClickable.href = DATASongInformation["CollectionKeyB"]
    HTMLArtistClickable.innerHTML = DATASongInformation["CollectionKeyE"]
    HTMLArtistHyperLinkDiv.classList.add("artist-hyperlinks")
    HTMLArtistHyperLinkDiv.appendChild(HTMLArtistClickable)
    HTMLlistedSongContainer.appendChild(HTMLArtistHyperLinkDiv)

    //Creates a div to hold the image. Then creates img element and stores it within HTMLCoverImage.
    //With HTMLCoverImage acting as <img></img> we use the src property to put content inside the tag.
    //The source of the image is set be the information linked to key C.
    //After the img is filled with content it is added to the div meant to hold the image.
    //After the div is filled with content it is added to the encompassing div containing the entire body.
    var HTMLSongImageDiv = document.createElement('div');
    var HTMLCoverImage = document.createElement("img"); HTMLCoverImage.src = DATASongInformation["CollectionKeyC"]
    HTMLCoverImage.classList.add("song-image-attributes") 
    HTMLSongImageDiv.appendChild(HTMLCoverImage)
    HTMLlistedSongContainer.appendChild(HTMLSongImageDiv)

    var HTMLSongDurationDiv = document.createElement('div');
    HTMLSongDurationDiv.innerHTML = DATASongInformation["CollectionKeyD"]
    HTMLSongDurationDiv.classList.add("bobify-body")
    HTMLlistedSongContainer.appendChild(HTMLSongDurationDiv)

    console.log(HTMLlistedSongContainer)
    console.log(HTMLCoverImage)

    HTMLBobifySongListing.appendChild(HTMLlistedSongContainer)
}
