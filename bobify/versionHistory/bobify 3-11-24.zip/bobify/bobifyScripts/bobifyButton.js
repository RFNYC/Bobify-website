 /*Data Type: Number - Stores the value 4 under "number_of_song_titles_listed"*/
 var number_of_song_titles_listed = 4; 

 /*Data Type: String - Stores the words "bobify classics" under "collection_title"*/
 var collection_title = "bobify classics";

     /*Data Type: Array - Stores a list of strings (song titles in this case) under the variable "listed_titles"*/
 var listed_titles = ["Dancing in the Moonlight", "Space Oddity", "House of the Rising Sun", "Sittin on the Dock of the Bay"]
 
 /*Data Type: Object - Creates a dictionary like list that stores keys in correlation to song names, number arrays, and boolean values (in this case)*/
 /*I addressed the the key issue. I wanted to id them by the order they would play if you started the playlist without shuffling it.*/
 var bobify_titles_dictionary = {
     "Q1": "Dancing in the Moonlight",
     "Q2": "Space Oddity",
     "Q3": "House of the Rising Sun",
     "Q4": "(Sittin' On) the Dock of the Bay",
     "queue": ["Dancing in the Moonlight", "Space Oddity", "House of the Rising Sun", "Sittin on the Dock of the Bay"],
     "favorite-order": [2,1,3,4],
     "shuffled": false
     }


     /*
     Tells HTML to do "alert(Congratulations....." When youpressedtheuglybutton function is called *WITH AN ARGUMENT*
     So if you do <button onclick="youpressedtheuglybutton(bobifyuser)"></button> it will automatically write the alert prompt.

     The ingredient/argument in this function is the user of the website. The function knows someone pressed the button but we have
     to tell it WHO pressed the button. Then the alert will use the preset below to address the person we said pressed it.

     In this case the data type of the argument can be a string because we only need a word name.
     */
     function youpressedtheuglybutton(bobifyuser){

         alert("Congratulations "+bobifyuser+" you pressed the ugly button.");

     };


console.log("bobifyButton.js: Active")